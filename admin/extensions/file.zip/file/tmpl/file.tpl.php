<div id="cel_[FIELD_ID]" class="download">
    <span class="title">[TITLE]</span> 
    <a href="[URL]"   alt="[TITLE_FILE]" class="downloads" target="_blank" />[TITLE_FILE]</a>
</div>

