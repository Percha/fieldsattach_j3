<li><a href="[URL2]" class="nyroModal" title="[TITLE]" rel="gal_[ARTICLE_ID]"><img src="[URL1]" alt="[TITLE]" /></a></li>
 
